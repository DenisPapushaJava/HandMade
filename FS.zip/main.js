$(document).ready(function(){
    $('.burger-menu').click(function(event){
        $('.burger-menu, .bg-lists').toggleClass('active');
    });
});